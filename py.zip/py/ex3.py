#Over the summer, temperatures in Yorkshire reached 38.4C. Write a program thatconverts this value in Celsius to the equivalent temperature in Fahrenheit, and thendisplays both.
c=38.4
f=(c*9/5)+32
print(f)
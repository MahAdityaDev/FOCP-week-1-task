#In a long career for Yorkshire, Geoffrey Boycott played 609 matches, batted 1014times, was not out 162 times, and scored 48426 runs. Write a program to calculateand display Boycott's batting average.
batted=1014
not_out=162
total_runs=48426
innings=batted-not_out
avg=total_runs/innings
print(avg)
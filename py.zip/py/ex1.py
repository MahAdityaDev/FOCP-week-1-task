#Write a program that prints a cheery message (such as "Hello World") on thescreen. Run it, and note that you have taken the first step to becoming a programmer!
print("hello world")
#So if your name is Herbert the message should become:Hello, Herbert!Note: Very few programs are written from scratch. It is usually best to start with aprogram that you know works, and ideally does something similar to the new
print("hello,aditya")
